export interface IContent {
  author: String;
  paragraphs: [String];
  title: String;
  id: String;
  created_at: Number;
}
